<!-- Blog Post -->
<?php if($news->getSearch()); ?>
<?php foreach($news->getSearch() as $new){ ?>
<?php $nama = $news->getUsers(); ?>
<div class="card mb-4">
  <img class="card-img-top" src="<?php echo $new['image_news'] ?>" alt="Card image cap">
  <div class="card-body">
    <h2 class="card-title"><?php echo $new['title'] ?></h2>
    <p class="card-text"><?php echo substr($new['news'],0,100) ?></p>
    <a href="?detail=<?php echo $new['id'] ?>" class="btn btn-primary">Read More &rarr;</a>
  </div>
  <div class="card-footer text-muted">
    Posted on <?php echo $new['date_post'] ?> by
    <a href="#"><?php echo $nama['username'] ?></a>
  </div>
</div>
<?php } ?>