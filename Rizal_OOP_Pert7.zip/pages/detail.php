<?php $result = $news->getDetail($_GET['detail']) ?>
<?php if($_POST) $news->insertData($_POST); ?>
<?php $nama = $news->getUsers(); ?>
<!-- Title -->
<h1 class="mt-4"><?php echo $result['title'] ?></h1>

<!-- Author -->
<p class="lead">
  by
  <a href="#"><?php echo $nama['username'] ?></a>
</p>

<hr>

<!-- Date/Time -->
<p>Posted on <?php echo $result['date_post'] ?></p>

<hr>

<!-- Preview Image -->
<img class="img-fluid rounded" src="<?php echo $result['image_news'] ?>" alt="">

<hr>

<!-- Post Content -->
<p class="lead"><?php echo $result['news'] ?></p>
<blockquote class="blockquote">
  <footer class="blockquote-footer">Someone famous in
    <cite title="Source Title">Source Title</cite>
  </footer>
</blockquote>

<hr>

<!-- Comments Form -->
<div class="card my-4">
  <h5 class="card-header">Leave a Comment:</h5>
  <div class="card-body">
    <form method="post">
      <div class="form-group">
        <input class="form-control" name="nama" type="text">
      </div>
      <div class="form-group">
        <textarea class="form-control" rows="3" name="reply"></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
      <input type="hidden" value="<?php echo $result['id'] ?>" name="post_id">
    </form>
  </div>
</div>
<?php if(isset($_GET['success'])){ echo "<div class='alert alert-success'>Komentar Sukses</div>";}?>
<!-- Single Comment -->
<?php foreach($news->getKomentar($result['id']) as $rows){ ?>
<div class="media mb-4">
  <img class="d-flex mr-3 rounded-circle" src="<?php echo $new['image_news'] ?>" alt="">
  <div class="media-body">
    <h5 class="mt-0"><?php echo $rows['username'] ?></h5>
    <?php echo $rows['reply'] ?>
  </div>
</div>
<?php } ?>