<?php 
namespace controller;

//import class
use PDO;

class Database extends PDO{
	private $host = 'localhost';
	private $dbname = 'blog_db';
	private $username = 'root';
	private $password = '';

	public function __construct()
	{
		parent::__construct(
			'mysql:host='.$this->host.';dbname='.$this->dbname, 
			$this->username, 
			$this->password
		);
		
		\Cloudinary::config(array(
		 "cloud_name" => "murihat",
		 "api_key" => "554246981751746",
		 "api_secret" => "FUFg-eNaIOsM9KNPggUhhGZeSfk"
		));
	}

}

?>