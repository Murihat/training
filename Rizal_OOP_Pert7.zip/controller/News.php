<?php 
 namespace controller;

 use controller\Database as DB;

class News extends DB{
	public function getNews()
	{
		$sql = $this->prepare('SELECT * FROM posts');
		$sql->execute();

		return $sql->fetchAll();
	}

	public function getUsers()
	{
		$sql = $this->prepare('SELECT * FROM users WHERE id = "1"');
		$sql->execute();

		return $sql->fetch();
	}
	public function getDetail($id)
	{
		$sql = $this->prepare("SELECT * FROM posts WHERE id='$id'");
		$sql->execute();

		return $sql->fetch();
	}
	public function getCategory()
	{
		$sql = $this->prepare("SELECT * FROM category_blog");
		$sql->execute();

		return $sql->fetchAll();
	}
	public function getDetailCategory($id)
	{
		$sql = $this->prepare("SELECT * FROM posts WHERE id_category='$id'");
		$sql->execute();

		return $sql->fetchAll();
	}
	public function insertData($data)
		{
			$sql = $this->prepare(
				"INSERT comments(post_id, username,reply)
				VALUES('".$data['post_id']."', '".$data['nama']."', '".$data['reply']."') "
			);
			$sql->execute();
			header("location:index.php?detail=".$data['post_id']."&success");
			
		}
	public function getKomentar($data)
		{
			$sql = $this->prepare(
				"SELECT * FROM comments WHERE post_id = '$data' ORDER BY id DESC"
			);
			$sql->execute();
			return $sql->fetchAll();
		}
	public function getSearch()
	{
		$data = $_POST['keyword'];
		$sql = $this->prepare("SELECT * FROM posts WHERE title LIKE '%$data%'");
		$sql->execute();

		return $sql->fetchAll();
	}
}