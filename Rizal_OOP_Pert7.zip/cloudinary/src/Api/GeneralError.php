<?php

namespace Cloudinary\Api;

/**
 * Class GeneralError
 * @package Cloudinary\Api
 */
class GeneralError extends Error
{
}
