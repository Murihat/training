<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blog Home - Start Bootstrap Template</title>

    <!-- Bootstrap core CSS -->
    <link href="asset/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-home.css" rel="stylesheet">

    <script src='https://code.jquery.com/jquery-3.3.1.min.js'></script>
    <script src='js/jquery.ui.widget.js' type='text/javascript'></script>
    <script src='js/jquery.iframe-transport.js' type='text/javascript'></script>
    <script src='js/jquery.fileupload.js' type='text/javascript'></script>
    <script src='js/jquery.cloudinary.js' type='text/javascript'></script>

  </head>

  <body>
    <?php echo cloudinary_js_config();  ?>
    <?php
      if (array_key_exists('REQUEST_SCHEME', $_SERVER)) {
        $cors_location = $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["SERVER_NAME"] .
      dirname($_SERVER["SCRIPT_NAME"]) . "/cloudinary_cors.html";
      } else {
        $cors_location = "http://" . $_SERVER["HTTP_HOST"] . "/cloudinary_cors.html";
      }
  ?>