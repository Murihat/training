<?php 
include 'controller/Database.php';
include 'controller/News.php';

require 'cloudinary/src/Cloudinary.php';
require 'cloudinary/src/Uploader.php';
require 'cloudinary/src/Api.php';


$news = new \controller\News;

include 'include/head.php';
include 'pages/navigation.php';

    if(isset($_GET['detail'])){
      include 'pages/detail.php';
    }else if(isset($_GET['category'])){
      include 'pages/category.php';
    }else if(isset($_GET['cari'])){
      include 'pages/pencarian.php';
    }else{
      include 'pages/home.php';
    }
 
include 'pages/pagination.php'; 
include 'pages/sideBar.php'; 
include 'include/footer.php'; 
